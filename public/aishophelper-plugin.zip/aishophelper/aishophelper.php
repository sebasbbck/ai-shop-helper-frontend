<?php
/**
 * Plugin Name:       AiShopHelper
 * Plugin URI:        https://aishophelper.ai
 * Description:       Conecta este sitio de WordPress con aishophelper de forma segura.
 * Version:           1.1.2
 * Author:            AishopHelper, David Raffo, Jesús Pons
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       aishophelper
 */

// Evitar acceso directo al archivo
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Yoast_API_Manager' ) ) {

class Yoast_API_Manager {

    public function __construct() {
        add_action( 'rest_api_init', array( $this, 'register_api_routes' ) );
    }

    public function register_api_routes() {
        register_rest_route( 'yoast-api/v1', '/update-meta', array(
            'methods'             => 'POST',
            'callback'            => array( $this, 'update_yoast_meta' ),
            'permission_callback' => array( $this, 'check_route_permission' ),
            'args'                => array(
                'post_id' => array(
                    'required'          => true,
                    'validate_callback' => array( $this, 'validate_post_id' ),
                    'sanitize_callback' => 'absint',
                ),
                'yoast_title' => array(
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'yoast_description' => array(
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ) );
    }

    public function validate_post_id( $param ) {
        $post = get_post( (int) $param );
        if ( ! $post ) {
            return false;
        }
        $allowed_post_types = class_exists( 'WooCommerce' ) ? array( 'post', 'product' ) : array( 'post' );
        return in_array( $post->post_type, $allowed_post_types, true );
    }

    public function update_yoast_meta( $request ) {
        // Support both WP_REST_Request object and plain array
        if ( is_object( $request ) && method_exists( $request, 'get_param' ) ) {
            $post_id = $request->get_param( 'post_id' );
        } elseif ( is_array( $request ) && isset( $request['post_id'] ) ) {
            $post_id = $request['post_id'];
        } else {
            return new WP_Error( 'invalid_request', 'Invalid request object.', array( 'status' => 400 ) );
        }

        $post_id = absint( $post_id );

        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return new WP_Error(
                'rest_forbidden',
                'You do not have permission to edit this post.',
                array( 'status' => 403 )
            );
        }

        $fields_map = array(
            'yoast_title'       => '_yoast_wpseo_title',
            'yoast_description' => '_yoast_wpseo_metadesc',
        );

        $results = array();

        foreach ( $fields_map as $param_name => $meta_key ) {
            if ( $request->has_param( $param_name ) ) {
                $value = $request->get_param( $param_name );
                update_post_meta( $post_id, $meta_key, $value );
                $results[ $param_name ] = 'updated';
            }
        }

        return rest_ensure_response( $results );
    }

    public function check_route_permission() {
        return current_user_can( 'edit_posts' );
    }
}

} // class_exists

/**
 * Añade la página de conexión al menú de administración.
 */
function msc_agregar_pagina_admin() {
    add_submenu_page(
        'options.php',
        'Conectar con Aishophelper',
        'Conectar Aishophelper',
        'manage_options',
        'aishophelper-conectar',
        'msc_renderizar_pagina_conexion'
    );
}
add_action( 'admin_menu', 'msc_agregar_pagina_admin' );

/**
 * Procesa el formulario POST antes de que se envíe HTML.
 */
function msc_procesar_conexion_post() {
    if ( isset( $_POST['msc_aprobar_submit'] ) && isset( $_GET['page'] ) && $_GET['page'] === 'aishophelper-conectar' ) {
        
        if ( ! check_admin_referer( 'msc_aprobar_conexion' ) ) {
            wp_die('Error de seguridad. Por favor, inténtalo de nuevo.');
        }

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die('No tienes permisos para realizar esta acción.');
        }

        // Verificar que los campos necesarios están presentes antes de usarlos.
        if ( ! isset( $_POST['msc_token'], $_POST['msc_callback_url'] ) ) {
            wp_die('Error: Faltan datos del formulario. Por favor, inténtalo de nuevo desde Aishophelper.');
        }

        $request_token = sanitize_text_field( wp_unslash( $_POST['msc_token'] ) );
        $callback_url = esc_url_raw( wp_unslash( $_POST['msc_callback_url'] ) );
        $user_id = get_current_user_id();
        // ===== AÑADIDO: Verificación de que el callback no está vacío =====
        if ( empty($callback_url) ) {
            wp_die('Error: La URL de retorno (callback) no puede estar vacía. El proceso no puede continuar.');
        }
        // =================================================================

        if ( ! class_exists( 'WP_Application_Passwords' ) ) {
            wp_die('Error: Este plugin requiere WordPress 5.6 o superior.');
        }

        $app_name = 'Conexión AIshophelper (' . home_url() . ')';
        $password_data = WP_Application_Passwords::create_new_application_password(
            $user_id,
            array( 'name' => $app_name )
        );

        if ( is_wp_error( $password_data ) ) {
            set_transient( 'msc_api_error', 'Error al crear la clave: ' . esc_html($password_data->get_error_message()), 45 );
            wp_safe_redirect( admin_url( 'admin.php?page=aishophelper-conectar' ) );
            exit;
        }

        $nueva_password = $password_data[0];
        $usuario_actual = wp_get_current_user();

        $redirect_url = add_query_arg( array(
            'token'        => $request_token,
            'app_password' => urlencode($nueva_password),
            'site_url'     => get_site_url(),
            'user'         => $usuario_actual->user_login
        ), $callback_url );

        $host_to_allow = wp_parse_url( $callback_url, PHP_URL_HOST );

        // Usar una función anónima (closure) para añadir el host de forma segura.
        // Esto evita que la función del filtro acceda a $_POST y resuelve el warning.
        $add_host_filter = function( $hosts ) use ( $host_to_allow ) {
            if ( $host_to_allow ) {
                $hosts[] = $host_to_allow;
            }
            return $hosts;
        };

        add_filter( 'allowed_redirect_hosts', $add_host_filter );

        wp_safe_redirect( $redirect_url );

        // Eliminar el filtro para no afectar otras redirecciones.
        remove_filter( 'allowed_redirect_hosts', $add_host_filter );
        exit;

    }
}
add_action( 'admin_init', 'msc_procesar_conexion_post' );


/**
 * Renderiza la página de conexión (Lógica GET).
 */
function msc_renderizar_pagina_conexion() {
    if ( ! class_exists( 'WP_Application_Passwords' ) ) {
        wp_die('Error: Este plugin requiere WordPress 5.6 o superior.');
    }
    
    ?>
    <div class="wrap">
        <h1><span class="dashicons dashicons-lock" style="font-size: 30px; margin-right: 10px;"></span>Conectar con Aishophelper</h1>

        <?php
        if ( $error_message = get_transient( 'msc_api_error' ) ) {
            echo '<div class="error"><p>' . esc_html( $error_message ) . '</p></div>';
            delete_transient( 'msc_api_error' );
        }

        // phpcs:disable WordPress.Security.NonceVerification.Recommended
        if ( ! isset($_GET['token'], $_GET['callback_url']) || empty($_GET['token']) || empty($_GET['callback_url']) ) {
            echo '<div class="error"><p>Error: Faltan parámetros de conexión. Por favor, inicia el proceso desde tu panel de Aishophelper de nuevo.</p></div>';
            return;
        }

        $request_token = sanitize_text_field( wp_unslash( $_GET['token'] ) );
        $callback_url = esc_url_raw( wp_unslash( $_GET['callback_url'] ) );
        // phpcs:enable

        ?>
        <div class="notice notice-info inline">
            <p style="font-size: 1.2em;">Estás a punto de conectar este sitio WordPress con <strong>Aishophelper</strong>.</p>
        </div>
        
        <p>Al hacer clic en "Aprobar", se creará una <strong>Contraseña de Aplicación</strong>. Esto permitirá que "Aishophelper" acceda a tu sitio para poder generarte blogs. En caso de que Wordfence esté activo, se configurará para que no interfiera con esta conexión.</p>
        <p>Esta acción es segura y no expone tu contraseña principal.</p>

        <!-- ======================================================================= -->
        <!-- CAMBIO PRINCIPAL AQUÍ: Se ha eliminado el atributo 'action' del form   -->
        <!-- ======================================================================= -->
        <form method="post" action="" style="margin-top: 20px;">
            <input type="hidden" name="msc_token" value="<?php echo esc_attr($request_token); ?>" />
            <input type="hidden" name="msc_callback_url" value="<?php echo esc_attr($callback_url); ?>" />
            
            <?php wp_nonce_field( 'msc_aprobar_conexion' ); ?>
            
            <?php submit_button( 'Aprobar y Conectar', 'primary large', 'msc_aprobar_submit' ); ?>
            
            <a href="<?php echo esc_url(admin_url()); ?>" class="button button-secondary" style="margin-left: 10px;">
                Cancelar
            </a>
        </form>
    </div>
    <?php
}

/**
 * Al activar el plugin, se asegura de que Wordfence no bloquee las contraseñas de aplicación.
 */
function msc_activar_plugin() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'wfconfig';

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table_name ) ) ) === $table_name ) {
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
        $wpdb->update(
            $table_name,
            array( 'val' => '0' ), // 0 = Habilitar contraseñas de aplicación
            array( 'name' => 'loginSec_disableApplicationPasswords' ),
            array( '%s' ),
            array( '%s' )
        );
    }
}

register_activation_hook( __FILE__, 'msc_activar_plugin' );

// Inicializa el gestor de la API de Yoast
new Yoast_API_Manager();